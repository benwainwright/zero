import{u as a}from"./use-events-BzQNw1ET.js";const u=(o,t)=>{a(s=>{s.key===o&&t(s.data)})};export{u};
