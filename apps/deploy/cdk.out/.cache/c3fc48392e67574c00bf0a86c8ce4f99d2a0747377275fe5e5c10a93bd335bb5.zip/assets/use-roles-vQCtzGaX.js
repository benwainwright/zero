import{u as r}from"./use-data-Qeg4wdiC.js";const a=(e,o)=>{const{data:t}=r({query:"GetRoles",refreshOn:["RoleCreated","RoleDeleted","RoleUpdated"]},{offset:e,limit:o});return t};export{a as u};
